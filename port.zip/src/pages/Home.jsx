import Navbar from "../components/Navbar/Navbar";
import Hero from "../components/Hero/Hero";
import About from "../components/About/About";
import Skills from "../components/Skills/Skills";
import Projects from "../components/Projects/Projects";
import Education from "../components/Education/Education";
import Experience from "../components/Experience/Experience";
// Add these later when you create the components
// import Experience from "../components/Experience/Experience";
// import Certifications from "../components/Certifications/Certifications";
// import GithubStats from "../components/GithubStats/GithubStats";
import Contact from "../components/Contact/Contact";
// import Footer from "../components/Footer/Footer";

const Home = () => {
  return (
    <main
      id="home"
      className="relative min-h-screen overflow-hidden bg-[#020617] text-white"
    >
      {/* Main Background Effects */}
      <div className="pointer-events-none fixed inset-0 z-0">
        <div className="absolute left-[-10%] top-[-10%] h-[350px] w-[350px] rounded-full bg-cyan-500/20 blur-[120px]" />
        <div className="absolute right-[-10%] top-[20%] h-[380px] w-[380px] rounded-full bg-violet-500/20 blur-[130px]" />
        <div className="absolute bottom-[-10%] left-[30%] h-[320px] w-[320px] rounded-full bg-blue-500/10 blur-[120px]" />

        <div className="absolute inset-0 bg-[linear-gradient(to_right,rgba(148,163,184,0.06)_1px,transparent_1px),linear-gradient(to_bottom,rgba(148,163,184,0.06)_1px,transparent_1px)] bg-[size:60px_60px]" />
        <div className="absolute inset-0 bg-gradient-to-b from-[#020617]/40 via-[#020617]/80 to-[#020617]" />
      </div>

      {/* Page Content */}
      <div className="relative z-10">
         <Navbar />
      <Hero />
      <About />
      <Education />
      <Skills />
      <Projects />
      <Experience />
      <Contact />
        {/* Add these when ready */}
        {/* <Certifications /> */}
        {/* <GithubStats /> */}
        {/* <Footer /> */}
      </div>
    </main>
  );
};

export default Home;