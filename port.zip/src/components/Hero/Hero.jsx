import { motion } from "framer-motion";
import { TypeAnimation } from "react-type-animation";
import {
  FaGithub,
  FaLinkedinIn,
  FaDownload,
  FaArrowRight,
  FaPython,
  FaDatabase,
  FaBrain,
} from "react-icons/fa";
import { SiGoogleanalytics, SiFastapi, SiReact } from "react-icons/si";
const Hero = () => {
  const floatingIcons = [
    {
      icon: <FaPython />,
      className: "left-[8%] top-[20%]",
      delay: 0,
    },
    {
      icon: <FaBrain />,
      className: "right-[10%] top-[22%]",
      delay: 0.3,
    },
    {
      icon: <SiGoogleanalytics />,
      className: "left-[12%] bottom-[18%]",
      delay: 0.6,
    },
    {
      icon: <SiReact />,
      className: "right-[14%] bottom-[16%]",
      delay: 0.9,
    },
  ];

  const stats = [
    {
      value: "04+",
      label: "Major Projects",
    },
    {
      value: "AI/ML",
      label: "Career Focus",
    },
    {
      value: "M.Sc.",
      label: "CA & IT Student",
    },
  ];

  return (
    <section
      id="home"
      className="relative flex min-h-screen items-center justify-center overflow-hidden px-5 pb-16 pt-28 sm:px-6 lg:px-8"
    >
      {/* Floating Tech Icons */}
      {floatingIcons.map((item, index) => (
        <motion.div
          key={index}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: [0, -15, 0] }}
          transition={{
            opacity: { duration: 0.8, delay: item.delay },
            y: {
              duration: 4,
              repeat: Infinity,
              ease: "easeInOut",
              delay: item.delay,
            },
          }}
          className={`pointer-events-none absolute hidden h-14 w-14 items-center justify-center rounded-2xl border border-cyan-400/20 bg-slate-900/60 text-2xl text-cyan-300 shadow-[0_0_30px_rgba(6,182,212,0.12)] backdrop-blur-xl lg:flex ${item.className}`}
        >
          {item.icon}
        </motion.div>
      ))}

      <div className="mx-auto grid w-full max-w-7xl items-center gap-14 lg:grid-cols-[1.1fr_0.9fr]">
        {/* Left Content */}
        <motion.div
          initial={{ opacity: 0, x: -70 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.9, ease: "easeOut" }}
          className="text-center lg:text-left"
        >
          <motion.div
            initial={{ opacity: 0, y: 18 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.15, duration: 0.7 }}
            className="mb-5 inline-flex items-center gap-2 rounded-full border border-cyan-400/20 bg-cyan-400/10 px-4 py-2 text-sm font-medium text-cyan-200 shadow-[0_0_30px_rgba(6,182,212,0.08)]"
          >
            <span className="h-2 w-2 rounded-full bg-cyan-300 shadow-[0_0_14px_rgba(103,232,249,0.9)]" />
            Available for AI/ML & Data Analytics 
          </motion.div>

          <motion.h1
            initial={{ opacity: 0, y: 24 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.25, duration: 0.8 }}
            className="text-4xl font-black leading-tight text-white sm:text-5xl md:text-6xl xl:text-7xl"
          >
            Hi, I&apos;m{" "}
            <span className="bg-gradient-to-r from-cyan-300 via-blue-400 to-violet-500 bg-clip-text text-transparent">
              Dhruv Mali
            </span>
          </motion.h1>

          <motion.div
            initial={{ opacity: 0, y: 24 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.35, duration: 0.8 }}
            className="mt-5 min-h-[42px] text-2xl font-bold text-cyan-300 sm:text-3xl md:text-4xl"
          >
            <TypeAnimation
              sequence={[
                "AI/ML Engineer",
                1800,
                "Data Analyst",
                1800,
                "Python Developer",
                1800,
                "Power BI Enthusiast",
                1800,
              ]}
              wrapper="span"
              speed={45}
              repeat={Infinity}
              cursor={true}
            />
          </motion.div>

          <motion.p
            initial={{ opacity: 0, y: 24 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.45, duration: 0.8 }}
            className="mx-auto mt-6 max-w-2xl text-base leading-8 text-slate-300 sm:text-lg lg:mx-0"
          >
            M.Sc. CA & IT student focused on building intelligent, data-driven applications using
            Python, Machine Learning, FastAPI, React, Power BI, and modern analytics workflows.
          </motion.p>

          {/* CTA Buttons */}
          <motion.div
            initial={{ opacity: 0, y: 24 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.55, duration: 0.8 }}
            className="mt-9 flex flex-col justify-center gap-4 sm:flex-row lg:justify-start"
          >
            <a
              href="#projects"
              className="group inline-flex items-center justify-center gap-2 rounded-full bg-gradient-to-r from-cyan-400 to-violet-500 px-7 py-3.5 text-sm font-bold text-slate-950 shadow-[0_0_30px_rgba(6,182,212,0.25)] transition hover:scale-105 hover:shadow-[0_0_45px_rgba(139,92,246,0.35)]"
            >
              View Projects
              <FaArrowRight className="transition group-hover:translate-x-1" />
            </a>

            <a
              href="/Dhruv_Mali_Resume.pdf"
              download
              className="group inline-flex items-center justify-center gap-2 rounded-full border border-cyan-400/40 bg-slate-900/60 px-7 py-3.5 text-sm font-bold text-cyan-200 backdrop-blur-xl transition hover:border-cyan-300 hover:bg-cyan-400/10 hover:shadow-[0_0_30px_rgba(6,182,212,0.2)]"
            >
              <FaDownload className="transition group-hover:translate-y-0.5" />
              Download Resume
            </a>
          </motion.div>

          {/* Social Links */}
          <motion.div
            initial={{ opacity: 0, y: 24 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.65, duration: 0.8 }}
            className="mt-8 flex items-center justify-center gap-4 lg:justify-start"
          >
            <a
              href="https://github.com/DHRUVMALI007"
              target="_blank"
              rel="noreferrer"
              aria-label="GitHub"
              className="flex h-12 w-12 items-center justify-center rounded-2xl border border-slate-700/70 bg-slate-900/60 text-xl text-slate-300 backdrop-blur-xl transition hover:border-cyan-400/60 hover:text-cyan-300 hover:shadow-[0_0_24px_rgba(6,182,212,0.22)]"
            >
              <FaGithub />
            </a>

            <a
              href="https://www.linkedin.com/in/dhruv-mali-b6305027a/"
              target="_blank"
              rel="noreferrer"
              aria-label="LinkedIn"
              className="flex h-12 w-12 items-center justify-center rounded-2xl border border-slate-700/70 bg-slate-900/60 text-xl text-slate-300 backdrop-blur-xl transition hover:border-cyan-400/60 hover:text-cyan-300 hover:shadow-[0_0_24px_rgba(6,182,212,0.22)]"
            >
              <FaLinkedinIn />
            </a>
          </motion.div>

          {/* Stats */}
          <motion.div
            initial={{ opacity: 0, y: 24 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.75, duration: 0.8 }}
            className="mt-10 grid grid-cols-3 gap-3 sm:max-w-xl lg:max-w-lg"
          >
            {stats.map((item) => (
              <div
                key={item.label}
                className="rounded-2xl border border-slate-700/60 bg-slate-900/50 p-4 text-center backdrop-blur-xl"
              >
                <h3 className="text-xl font-black text-cyan-300 sm:text-2xl">{item.value}</h3>
                <p className="mt-1 text-xs text-slate-400 sm:text-sm">{item.label}</p>
              </div>
            ))}
          </motion.div>
        </motion.div>

        {/* Right Visual */}
        <motion.div
          initial={{ opacity: 0, x: 70 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.9, ease: "easeOut", delay: 0.2 }}
          className="relative mx-auto flex w-full max-w-[430px] items-center justify-center lg:mx-0 lg:ml-auto"
        >
          <div className="absolute h-[340px] w-[340px] rounded-full bg-cyan-400/20 blur-[90px]" />
          <div className="absolute h-[280px] w-[280px] rounded-full bg-violet-500/20 blur-[80px]" />

          <motion.div
            animate={{ y: [0, -14, 0] }}
            transition={{ duration: 5, repeat: Infinity, ease: "easeInOut" }}
            className="relative w-full rounded-[2rem] border border-cyan-400/20 bg-slate-900/60 p-5 shadow-[0_0_60px_rgba(6,182,212,0.12)] backdrop-blur-2xl"
          >
            <div className="rounded-[1.5rem] border border-slate-700/70 bg-[#020617]/80 p-6">
              <div className="mb-5 flex items-center gap-2">
                <span className="h-3 w-3 rounded-full bg-red-400" />
                <span className="h-3 w-3 rounded-full bg-yellow-400" />
                <span className="h-3 w-3 rounded-full bg-green-400" />
              </div>

              <div className="space-y-4 font-mono text-sm">
                <p className="text-slate-500"># AI Engineer Profile</p>
                <p>
                  <span className="text-violet-300">name</span>
                  <span className="text-slate-400"> = </span>
                  <span className="text-cyan-300">&quot;Dhruv Mali&quot;</span>
                </p>
                <p>
                  <span className="text-violet-300">focus</span>
                  <span className="text-slate-400"> = </span>
                  <span className="text-cyan-300">
                    [&quot;AI&quot;, &quot;ML&quot;, &quot;Data&quot;]
                  </span>
                </p>
                <p>
                  <span className="text-violet-300">stack</span>
                  <span className="text-slate-400"> = </span>
                  <span className="text-cyan-300">
                    [&quot;Python&quot;, &quot;FastAPI&quot;, &quot;React&quot;]
                  </span>
                </p>
                <p>
                  <span className="text-violet-300">status</span>
                  <span className="text-slate-400"> = </span>
                  <span className="text-green-300">&quot;Open to Opportunities&quot;</span>
                </p>
              </div>

              <div className="mt-6 rounded-2xl border border-cyan-400/20 bg-cyan-400/10 p-4">
                <div className="mb-3 flex items-center justify-between">
                  <span className="text-sm font-semibold text-slate-300">Model Training</span>
                  <span className="text-sm font-bold text-cyan-300">92%</span>
                </div>
                <div className="h-2 overflow-hidden rounded-full bg-slate-800">
                  <motion.div
                    initial={{ width: 0 }}
                    animate={{ width: "92%" }}
                    transition={{ duration: 1.5, delay: 1 }}
                    className="h-full rounded-full bg-gradient-to-r from-cyan-400 to-violet-500"
                  />
                </div>
              </div>

              <div className="mt-5 grid grid-cols-3 gap-3">
                <div className="rounded-2xl bg-slate-900/80 p-3 text-center">
                  <FaBrain className="mx-auto text-xl text-cyan-300" />
                  <p className="mt-2 text-xs text-slate-400">AI</p>
                </div>
                <div className="rounded-2xl bg-slate-900/80 p-3 text-center">
                  <FaDatabase className="mx-auto text-xl text-violet-300" />
                  <p className="mt-2 text-xs text-slate-400">Data</p>
                </div>
                <div className="rounded-2xl bg-slate-900/80 p-3 text-center">
                  <SiFastapi className="mx-auto text-xl text-green-300" />
                  <p className="mt-2 text-xs text-slate-400">API</p>
                </div>
              </div>
            </div>
          </motion.div>
        </motion.div>
      </div>
    </section>
  );
};

export default Hero;
