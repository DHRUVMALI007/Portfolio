import { motion } from "framer-motion";
import {
  FaGithub,
  FaExternalLinkAlt,
  FaBrain,
  FaLaptopCode,
  FaChartLine,
} from "react-icons/fa";
import { MdAutoGraph } from "react-icons/md";

const projects = [
  {
    title: "AI DataCleaner",
    category: "AI / ML Platform",
    status: "In Development",
    description:
      "An AI-powered data cleaning platform that automates preprocessing workflows including missing value handling, duplicate removal, outlier detection, feature encoding, dataset profiling, and ML-based cleaning recommendations.",
    tech: ["React", "FastAPI", "PostgreSQL", "Pandas", "Scikit-Learn"],
    image: "https://images.unsplash.com/photo-1551288049-bebda4e38f71",
    icon: <FaBrain />,
    gradient: "from-cyan-400 to-blue-500",
    github: "#",
    live: "#",
  },
  {
    title: "Laptop & PC Service Management System",
    category: "Full Stack Platform",
    status: "Completed",
    description:
      "A full-stack platform for laptop and PC sales, repair services, appointment booking, product management, order tracking, authentication, Razorpay payments, and automated email notifications.",
    tech: ["React", "Node.js", "Express.js", "MongoDB", "Razorpay"],
    image: "https://images.unsplash.com/photo-1516321318423-f06f85e504b3",
    icon: <FaLaptopCode />,
    gradient: "from-violet-400 to-purple-500",
    github: "#",
    live: "#",
  },
  {
    title: "PipOpt",
    category: "AI Trading Optimization",
    status: "Completed",
    description:
      "An AI-driven stock market analysis platform for trend prediction and strategy optimization using machine learning, financial data preprocessing, feature engineering, predictive insights, and model evaluation.",
    tech: ["Python", "Machine Learning", "Pandas", "NumPy", "Power BI"],
    image: "https://images.unsplash.com/photo-1611974789855-9c2a0a7236a3",
    icon: <FaChartLine />,
    gradient: "from-emerald-400 to-cyan-500",
    github: "#",
    live: "#",
  },
  {
    title: "Power BI Dashboard",
    category: "Business Intelligence",
    status: "Completed",
    description:
      "A business intelligence dashboard for KPI monitoring, sales insights, revenue analysis, executive reporting, and data-driven decision-making using Power BI, SQL, and Excel.",
    tech: ["Power BI", "SQL", "Excel", "Data Visualization"],
    image: "https://images.unsplash.com/photo-1554224155-6726b3ff858f",
    icon: <MdAutoGraph />,
    gradient: "from-pink-400 to-violet-500",
    github: "#",
    live: "#",
  },
];

const Projects = () => {
  return (
    <section
      id="projects"
      className="relative mx-auto max-w-7xl overflow-hidden px-5 py-24 sm:px-6 lg:px-8"
    >
      <div className="pointer-events-none absolute left-0 top-1/3 h-[420px] w-[420px] rounded-full bg-cyan-500/5 blur-[120px]" />

      <motion.div
        initial={{ opacity: 0, y: 70 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true, amount: 0.2 }}
        transition={{ duration: 0.8, ease: "easeOut" }}
        className="relative z-10"
      >
        <div className="mx-auto mb-16 max-w-3xl text-center">
          <div className="mb-4 inline-flex items-center gap-2 rounded-full border border-cyan-400/20 bg-cyan-400/10 px-4 py-2 text-sm font-medium text-cyan-200">
            <FaBrain className="text-cyan-300" />
            Featured Work
          </div>

          <h2 className="text-4xl font-black text-white sm:text-5xl lg:text-6xl">
            AI, Data & Software{" "}
            <span className="bg-gradient-to-r from-cyan-300 via-blue-400 to-violet-500 bg-clip-text text-transparent">
              Projects
            </span>
          </h2>

          <p className="mt-6 text-base leading-8 text-slate-400 sm:text-lg">
            A selection of my best projects focused on AI automation, machine
            learning, data analytics, business intelligence, and full-stack
            development.
          </p>
        </div>

        <div className="grid gap-8 lg:grid-cols-2">
          {projects.map((project, index) => (
            <motion.article
              key={project.title}
              initial={{ opacity: 0, y: 60 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.7, delay: index * 0.12 }}
              whileHover={{ y: -10 }}
              className="group relative overflow-hidden rounded-[2rem] border border-slate-700/60 bg-slate-900/50 backdrop-blur-2xl transition duration-300 hover:border-cyan-400/40 hover:shadow-[0_0_60px_rgba(6,182,212,0.12)]"
            >
              <div
                className={`absolute inset-x-0 top-0 z-20 h-[2px] bg-gradient-to-r ${project.gradient}`}
              />

              <div className="relative h-64 overflow-hidden">
                <img
                  src={project.image}
                  alt={project.title}
                  className="h-full w-full object-cover transition duration-700 group-hover:scale-110"
                />

                <div className="absolute inset-0 bg-gradient-to-t from-[#020617] via-[#020617]/50 to-transparent" />

                <div className="absolute left-5 top-5 flex items-center gap-3">
                  <div
                    className={`flex h-12 w-12 items-center justify-center rounded-2xl bg-gradient-to-r ${project.gradient} text-xl text-slate-950 shadow-lg`}
                  >
                    {project.icon}
                  </div>

                  <span className="rounded-full border border-white/10 bg-slate-950/70 px-4 py-2 text-xs font-semibold text-slate-200 backdrop-blur-xl">
                    {project.category}
                  </span>
                </div>

                <div className="absolute right-5 top-5">
                  <span className="rounded-full border border-cyan-400/20 bg-cyan-400/10 px-4 py-2 text-xs font-bold text-cyan-200 backdrop-blur-xl">
                    {project.status}
                  </span>
                </div>
              </div>

              <div className="p-6 sm:p-8">
                <h3 className="text-2xl font-black text-white transition group-hover:text-cyan-300 sm:text-3xl">
                  {project.title}
                </h3>

                <p className="mt-4 min-h-[112px] leading-7 text-slate-400">
                  {project.description}
                </p>

                <div className="mt-6 flex flex-wrap gap-3">
                  {project.tech.map((tech) => (
                    <span
                      key={tech}
                      className="rounded-full border border-cyan-400/20 bg-cyan-400/10 px-3 py-1.5 text-xs font-semibold text-cyan-200"
                    >
                      {tech}
                    </span>
                  ))}
                </div>

                <div className="mt-8 flex flex-col gap-3 sm:flex-row">
                  <a
                    href={project.github}
                    target="_blank"
                    rel="noreferrer"
                    className="inline-flex items-center justify-center gap-2 rounded-full border border-slate-700 bg-slate-950/60 px-5 py-3 text-sm font-bold text-slate-300 transition hover:border-cyan-400/50 hover:text-cyan-300 hover:shadow-[0_0_24px_rgba(6,182,212,0.15)]"
                  >
                    <FaGithub />
                    GitHub
                  </a>

                  <a
                    href={project.live}
                    target="_blank"
                    rel="noreferrer"
                    className="inline-flex items-center justify-center gap-2 rounded-full bg-gradient-to-r from-cyan-400 to-violet-500 px-5 py-3 text-sm font-bold text-slate-950 transition hover:scale-105 hover:shadow-[0_0_30px_rgba(6,182,212,0.25)]"
                  >
                    <FaExternalLinkAlt />
                    Live Demo
                  </a>
                </div>
              </div>

              <div className="absolute -bottom-24 -right-24 h-48 w-48 rounded-full bg-cyan-400/5 blur-3xl transition group-hover:bg-cyan-400/10" />
            </motion.article>
          ))}
        </div>
      </motion.div>
    </section>
  );
};

export default Projects;