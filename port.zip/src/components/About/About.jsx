import { motion } from "framer-motion";
import { FaBrain, FaCode, FaChartLine, FaRocket } from "react-icons/fa";

const About = () => {
  const cards = [
    {
      icon: <FaBrain />,
      title: "AI & Machine Learning",
      description:
        "Building intelligent systems using machine learning, deep learning, predictive analytics, and automated data preprocessing workflows.",
      gradient: "from-cyan-400 to-blue-500",
      glow: "group-hover:shadow-cyan-500/20",
    },
    {
      icon: <FaChartLine />,
      title: "Data Analytics",
      description:
        "Transforming raw data into clear business insights using Python, Pandas, NumPy, SQL, Power BI, and visual analytics dashboards.",
      gradient: "from-violet-400 to-purple-500",
      glow: "group-hover:shadow-violet-500/20",
    },
    {
      icon: <FaCode />,
      title: "Development",
      description:
        "Developing scalable web applications and AI-powered platforms using React, Tailwind CSS, FastAPI, PostgreSQL, MongoDB, and modern tools.",
      gradient: "from-pink-400 to-violet-500",
      glow: "group-hover:shadow-pink-500/20",
    },
  ];

  return (
    <section
      id="about"
      className="relative mx-auto max-w-7xl overflow-hidden px-5 py-24 sm:px-6 lg:px-8"
    >
      {/* Background Glow */}
      <div className="pointer-events-none absolute left-1/2 top-1/2 h-[420px] w-[420px] -translate-x-1/2 -translate-y-1/2 rounded-full bg-cyan-500/5 blur-[120px]" />

      <motion.div
        initial={{ opacity: 0, y: 70 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true, amount: 0.2 }}
        transition={{ duration: 0.8, ease: "easeOut" }}
        className="relative z-10"
      >
        {/* Section Header */}
        <div className="mx-auto mb-16 max-w-3xl text-center">
          <motion.div
            initial={{ opacity: 0, y: 18 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.7 }}
            className="mb-4 inline-flex items-center gap-2 rounded-full border border-cyan-400/20 bg-cyan-400/10 px-4 py-2 text-sm font-medium text-cyan-200"
          >
            <FaRocket className="text-cyan-300" />
            About My Journey
          </motion.div>

          <motion.h2
            initial={{ opacity: 0, y: 24 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.7, delay: 0.1 }}
            className="text-4xl font-black text-white sm:text-5xl lg:text-6xl"
          >
            Building the Future with{" "}
            <span className="bg-gradient-to-r from-cyan-300 via-blue-400 to-violet-500 bg-clip-text text-transparent">
              AI & Data
            </span>
          </motion.h2>

          <motion.p
            initial={{ opacity: 0, y: 24 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.7, delay: 0.2 }}
            className="mt-6 text-base leading-8 text-slate-400 sm:text-lg"
          >
            I am an M.Sc. CA & IT student focused on Artificial Intelligence,
            Machine Learning, Data Analytics, and modern software development.
            My goal is to build intelligent applications that solve real-world
            problems and help businesses make better data-driven decisions.
          </motion.p>
        </div>

        {/* Main Bio Card */}
        <motion.div
          initial={{ opacity: 0, y: 35 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.7, delay: 0.25 }}
          className="mb-10 rounded-[2rem] border border-cyan-400/10 bg-slate-900/50 p-6 shadow-[0_0_60px_rgba(6,182,212,0.06)] backdrop-blur-2xl sm:p-8 lg:p-10"
        >
          <div className="grid gap-8 lg:grid-cols-[1fr_0.8fr] lg:items-center">
            <div>
              <h3 className="text-2xl font-bold text-white sm:text-3xl">
                From Data to Intelligent Solutions
              </h3>

              <p className="mt-5 leading-8 text-slate-400">
                I work across the full data and development pipeline — from data
                preprocessing, feature engineering, and model evaluation to
                building full-stack platforms with clean UI and practical
                backend systems. My current focus is creating AI-powered tools
                such as DataCleaner and PipOpt for real-world automation,
                analytics, and decision support.
              </p>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="rounded-3xl border border-slate-700/60 bg-[#020617]/70 p-5 text-center">
                <h4 className="text-3xl font-black text-cyan-300">04+</h4>
                <p className="mt-2 text-sm text-slate-400">Major Projects</p>
              </div>

              <div className="rounded-3xl border border-slate-700/60 bg-[#020617]/70 p-5 text-center">
                <h4 className="text-3xl font-black text-violet-300">AI/ML</h4>
                <p className="mt-2 text-sm text-slate-400">Core Focus</p>
              </div>

              <div className="rounded-3xl border border-slate-700/60 bg-[#020617]/70 p-5 text-center">
                <h4 className="text-3xl font-black text-blue-300">Python</h4>
                <p className="mt-2 text-sm text-slate-400">Primary Language</p>
              </div>

              <div className="rounded-3xl border border-slate-700/60 bg-[#020617]/70 p-5 text-center">
                <h4 className="text-3xl font-black text-pink-300">Power BI</h4>
                <p className="mt-2 text-sm text-slate-400">Analytics Tool</p>
              </div>
            </div>
          </div>
        </motion.div>

        {/* Skill Direction Cards */}
        <div className="grid gap-6 md:grid-cols-3">
          {cards.map((card, index) => (
            <motion.div
              key={card.title}
              initial={{ opacity: 0, y: 45 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.7, delay: index * 0.15 }}
              whileHover={{ y: -10, scale: 1.02 }}
              className={`group relative overflow-hidden rounded-[2rem] border border-slate-700/60 bg-slate-900/50 p-7 backdrop-blur-2xl transition duration-300 hover:border-cyan-400/40 hover:shadow-2xl ${card.glow}`}
            >
              <div
                className={`absolute inset-x-0 top-0 h-[2px] bg-gradient-to-r ${card.gradient}`}
              />

              <div
                className={`mb-6 flex h-14 w-14 items-center justify-center rounded-2xl bg-gradient-to-r ${card.gradient} text-2xl text-slate-950 shadow-lg`}
              >
                {card.icon}
              </div>

              <h3 className="text-xl font-bold text-white">{card.title}</h3>

              <p className="mt-4 leading-7 text-slate-400">
                {card.description}
              </p>

              <div className="absolute -bottom-20 -right-20 h-40 w-40 rounded-full bg-cyan-400/5 blur-3xl transition group-hover:bg-cyan-400/10" />
            </motion.div>
          ))}
        </div>
      </motion.div>
    </section>
  );
};

export default About;