import { motion } from "framer-motion";
import {
  FaEnvelope,
  FaGithub,
  FaLinkedinIn,
  FaDownload,
  FaPaperPlane,
  FaMapMarkerAlt,
} from "react-icons/fa";

const Contact = () => {
  const contactCards = [
    {
      title: "Email",
      value: "dmali9786@gmail.com",
      description: "Send me a message directly",
      icon: <FaEnvelope />,
      link: "mailto:dmali9786@gmail.com",
      gradient: "from-cyan-400 to-blue-500",
    },
    {
      title: "LinkedIn",
      value: "Dhruv Mali",
      description: "Connect professionally",
      icon: <FaLinkedinIn />,
      link: "https://www.linkedin.com/in/dhruv-mali-b6305027a/",
      gradient: "from-blue-400 to-cyan-500",
    },
    {
      title: "GitHub",
      value: "DHRUVMALI007",
      description: "View my projects and code",
      icon: <FaGithub />,
      link: "https://github.com/DHRUVMALI007",
      gradient: "from-violet-400 to-purple-500",
    },
  ];

  return (
    <section
      id="contact"
      className="relative mx-auto max-w-7xl overflow-hidden px-5 py-24 sm:px-6 lg:px-8"
    >
      <div className="pointer-events-none absolute left-1/2 top-1/2 h-[420px] w-[420px] -translate-x-1/2 -translate-y-1/2 rounded-full bg-cyan-500/5 blur-[120px]" />

      <motion.div
        initial={{ opacity: 0, y: 70 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true, amount: 0.2 }}
        transition={{ duration: 0.8, ease: "easeOut" }}
        className="relative z-10"
      >
        {/* Section Header */}
        <div className="mx-auto mb-16 max-w-3xl text-center">
          <div className="mb-4 inline-flex items-center gap-2 rounded-full border border-cyan-400/20 bg-cyan-400/10 px-4 py-2 text-sm font-medium text-cyan-200">
            <FaPaperPlane className="text-cyan-300" />
            Get In Touch
          </div>

          <h2 className="text-4xl font-black text-white sm:text-5xl lg:text-6xl">
            Let&apos;s Build Something{" "}
            <span className="bg-gradient-to-r from-cyan-300 via-blue-400 to-violet-500 bg-clip-text text-transparent">
              Intelligent
            </span>
          </h2>

          <p className="mt-6 text-base leading-8 text-slate-400 sm:text-lg">
            Looking for an AI/ML Engineer, Data Analyst, Python Developer, or
            Software Developer? I am open to internships, job opportunities,
            freelance projects, and technical collaborations.
          </p>
        </div>

        <div className="grid gap-8 lg:grid-cols-[1.1fr_0.9fr]">
          {/* Contact Form */}
          <motion.div
            initial={{ opacity: 0, x: -45 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.7 }}
            className="rounded-[2rem] border border-slate-700/60 bg-slate-900/50 p-6 backdrop-blur-2xl transition hover:border-cyan-400/30 sm:p-8"
          >
            <h3 className="text-2xl font-black text-white">
              Send a Message
            </h3>

            <p className="mt-3 text-sm leading-7 text-slate-400">
              Fill out the form and I will get back to you for project,
              internship, freelance, or collaboration opportunities.
            </p>

            <form className="mt-8 space-y-5">
              <div className="grid gap-5 sm:grid-cols-2">
                <input
                  type="text"
                  name="name"
                  placeholder="Your Name"
                  className="w-full rounded-2xl border border-slate-700/70 bg-[#020617]/70 p-4 text-sm text-white outline-none transition placeholder:text-slate-500 focus:border-cyan-400/60 focus:shadow-[0_0_20px_rgba(6,182,212,0.12)]"
                />

                <input
                  type="email"
                  name="email"
                  placeholder="Your Email"
                  className="w-full rounded-2xl border border-slate-700/70 bg-[#020617]/70 p-4 text-sm text-white outline-none transition placeholder:text-slate-500 focus:border-cyan-400/60 focus:shadow-[0_0_20px_rgba(6,182,212,0.12)]"
                />
              </div>

              <input
                type="text"
                name="subject"
                placeholder="Subject"
                className="w-full rounded-2xl border border-slate-700/70 bg-[#020617]/70 p-4 text-sm text-white outline-none transition placeholder:text-slate-500 focus:border-cyan-400/60 focus:shadow-[0_0_20px_rgba(6,182,212,0.12)]"
              />

              <textarea
                rows="6"
                name="message"
                placeholder="Tell me about your opportunity or project..."
                className="w-full resize-none rounded-2xl border border-slate-700/70 bg-[#020617]/70 p-4 text-sm text-white outline-none transition placeholder:text-slate-500 focus:border-cyan-400/60 focus:shadow-[0_0_20px_rgba(6,182,212,0.12)]"
              />

              <button
                type="submit"
                className="group inline-flex w-full items-center justify-center gap-2 rounded-full bg-gradient-to-r from-cyan-400 to-violet-500 px-7 py-4 text-sm font-black text-slate-950 transition hover:scale-[1.02] hover:shadow-[0_0_35px_rgba(6,182,212,0.25)]"
              >
                <FaPaperPlane className="transition group-hover:translate-x-1" />
                Send Message
              </button>
            </form>
          </motion.div>

          {/* Contact Info */}
          <motion.div
            initial={{ opacity: 0, x: 45 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.7 }}
            className="space-y-5"
          >
            <div className="rounded-[2rem] border border-slate-700/60 bg-slate-900/50 p-6 backdrop-blur-2xl">
              <div className="mb-5 flex items-center gap-3">
                <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-cyan-400/10 text-xl text-cyan-300">
                  <FaMapMarkerAlt />
                </div>

                <div>
                  <h3 className="text-xl font-bold text-white">
                    Based In
                  </h3>
                  <p className="text-sm text-slate-400">
                    Ahmedabad, Gujarat, India
                  </p>
                </div>
              </div>

              <p className="leading-7 text-slate-400">
                Available for AI/ML, Data Analytics, Python Development,
                Full-Stack Development, internship roles, freelance work, and
                professional collaborations.
              </p>
            </div>

            {contactCards.map((card, index) => (
              <motion.a
                key={card.title}
                href={card.link}
                target={card.link.startsWith("mailto") ? "_self" : "_blank"}
                rel="noreferrer"
                initial={{ opacity: 0, y: 35 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                whileHover={{ y: -6 }}
                className="group block overflow-hidden rounded-[2rem] border border-slate-700/60 bg-slate-900/50 p-6 backdrop-blur-2xl transition hover:border-cyan-400/40 hover:shadow-[0_0_40px_rgba(6,182,212,0.1)]"
              >
                <div className="flex items-center gap-4">
                  <div
                    className={`flex h-14 w-14 items-center justify-center rounded-2xl bg-gradient-to-r ${card.gradient} text-2xl text-slate-950`}
                  >
                    {card.icon}
                  </div>

                  <div>
                    <h3 className="text-xl font-bold text-white transition group-hover:text-cyan-300">
                      {card.title}
                    </h3>

                    <p className="mt-1 text-sm text-slate-400">
                      {card.description}
                    </p>

                    <p className="mt-1 text-sm font-semibold text-cyan-300">
                      {card.value}
                    </p>
                  </div>
                </div>
              </motion.a>
            ))}

            <a
              href="/Dhruv_Mali_Resume.pdf"
              download
              className="group flex items-center justify-center gap-3 rounded-full border border-cyan-400/40 bg-cyan-400/10 px-7 py-4 text-sm font-black text-cyan-200 transition hover:bg-cyan-400 hover:text-slate-950 hover:shadow-[0_0_35px_rgba(6,182,212,0.25)]"
            >
              <FaDownload className="transition group-hover:translate-y-0.5" />
              Download Resume
            </a>
          </motion.div>
        </div>
      </motion.div>
    </section>
  );
};

export default Contact;