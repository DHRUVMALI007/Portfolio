import { useState } from "react";
import { FaBars, FaTimes, FaGithub, FaLinkedinIn } from "react-icons/fa";
import { HiOutlineDocumentDownload } from "react-icons/hi";
import { motion, AnimatePresence } from "framer-motion";

const Navbar = () => {
  const [menuOpen, setMenuOpen] = useState(false);

  const navItems = [
    { name: "About", link: "#about" },
    { name: "Education", link: "#education" },
    { name: "Skills", link: "#skills" },
    { name: "Projects", link: "#projects" },
    { name: "Experience", link: "#experience" },
    { name: "Contact", link: "#contact" },
  ];

  const socialLinks = [
    {
      icon: <FaGithub />,
      link: "https://github.com/DHRUVMALI007",
      label: "GitHub",
    },
    {
      icon: <FaLinkedinIn />,
      link: "https://www.linkedin.com/in/dhruv-mali-b6305027a/",
      label: "LinkedIn",
    },
  ];

  const closeMenu = () => {
    setMenuOpen(false);
  };

  return (
    <motion.nav
      initial={{ y: -80, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ duration: 0.7, ease: "easeOut" }}
      className="fixed left-0 top-0 z-50 w-full border-b border-cyan-400/10 bg-[#020617]/70 backdrop-blur-2xl"
    >
      <div className="mx-auto flex h-20 max-w-7xl items-center justify-between px-5 sm:px-6 lg:px-8">
        {/* Logo */}
        <a href="#home" className="group flex items-center gap-3">
          <div className="relative flex h-11 w-11 items-center justify-center rounded-2xl border border-cyan-400/30 bg-cyan-400/10 shadow-[0_0_25px_rgba(6,182,212,0.25)]">
            <span className="absolute inset-0 rounded-2xl bg-cyan-400/10 blur-md transition group-hover:bg-cyan-400/20" />
            <span className="relative text-lg font-black text-cyan-300">
              DM
            </span>
          </div>

          <div className="leading-tight">
            <h1 className="text-xl font-black tracking-wide text-white sm:text-2xl">
              Dhruv<span className="text-cyan-400">.AI</span>
            </h1>
            <p className="hidden text-xs font-medium tracking-[0.25em] text-slate-400 sm:block">
              AI / ML ENGINEER
            </p>
          </div>
        </a>

        {/* Desktop Menu */}
        <div className="hidden items-center gap-8 lg:flex">
          {navItems.map((item) => (
            <a
              key={item.name}
              href={item.link}
              className="group relative text-sm font-medium text-slate-300 transition hover:text-cyan-300"
            >
              {item.name}
              <span className="absolute -bottom-2 left-0 h-[2px] w-0 rounded-full bg-gradient-to-r from-cyan-400 to-violet-500 transition-all duration-300 group-hover:w-full" />
            </a>
          ))}
        </div>

        {/* Desktop Right Actions */}
        <div className="hidden items-center gap-3 lg:flex">
          {socialLinks.map((item) => (
            <a
              key={item.label}
              href={item.link}
              target="_blank"
              rel="noreferrer"
              aria-label={item.label}
              className="flex h-10 w-10 items-center justify-center rounded-xl border border-slate-700/70 bg-slate-900/60 text-slate-300 transition hover:border-cyan-400/60 hover:text-cyan-300 hover:shadow-[0_0_18px_rgba(6,182,212,0.25)]"
            >
              {item.icon}
            </a>
          ))}

          <a
            href="/Dhruv_Mali_Resume.pdf"
            download
            className="group ml-2 inline-flex items-center gap-2 rounded-full border border-cyan-400/40 bg-cyan-400/10 px-5 py-2.5 text-sm font-semibold text-cyan-200 transition hover:bg-cyan-400 hover:text-slate-950 hover:shadow-[0_0_25px_rgba(6,182,212,0.35)]"
          >
            <HiOutlineDocumentDownload className="text-lg transition group-hover:translate-y-0.5" />
            Resume
          </a>
        </div>

        {/* Mobile Menu Button */}
        <button
          onClick={() => setMenuOpen((prev) => !prev)}
          className="relative z-50 flex h-11 w-11 items-center justify-center rounded-xl border border-slate-700/70 bg-slate-900/70 text-xl text-slate-200 transition hover:border-cyan-400/50 hover:text-cyan-300 lg:hidden"
          aria-label="Toggle menu"
        >
          {menuOpen ? <FaTimes /> : <FaBars />}
        </button>
      </div>

      {/* Mobile Menu */}
      <AnimatePresence>
        {menuOpen && (
          <motion.div
            initial={{ opacity: 0, y: -18 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -18 }}
            transition={{ duration: 0.25 }}
            className="lg:hidden"
          >
            <div className="mx-4 mb-5 rounded-3xl border border-cyan-400/10 bg-slate-950/95 p-4 shadow-[0_20px_70px_rgba(0,0,0,0.45)] backdrop-blur-2xl">
              <div className="flex flex-col gap-1">
                {navItems.map((item, index) => (
                  <motion.a
                    key={item.name}
                    href={item.link}
                    onClick={closeMenu}
                    initial={{ opacity: 0, x: -18 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: index * 0.05 }}
                    className="rounded-2xl px-4 py-3 text-base font-medium text-slate-300 transition hover:bg-cyan-400/10 hover:text-cyan-300"
                  >
                    {item.name}
                  </motion.a>
                ))}
              </div>

              <div className="mt-4 h-px bg-gradient-to-r from-transparent via-slate-700 to-transparent" />

              <div className="mt-4 flex items-center justify-between gap-3">
                <div className="flex gap-3">
                  {socialLinks.map((item) => (
                    <a
                      key={item.label}
                      href={item.link}
                      target="_blank"
                      rel="noreferrer"
                      aria-label={item.label}
                      className="flex h-11 w-11 items-center justify-center rounded-xl border border-slate-700 bg-slate-900 text-slate-300 transition hover:border-cyan-400/60 hover:text-cyan-300"
                    >
                      {item.icon}
                    </a>
                  ))}
                </div>

                <a
                  href="/Dhruv_Mali_Resume.pdf"
                  download
                  onClick={closeMenu}
                  className="inline-flex items-center gap-2 rounded-full bg-gradient-to-r from-cyan-400 to-violet-500 px-5 py-2.5 text-sm font-bold text-slate-950 shadow-[0_0_25px_rgba(6,182,212,0.25)]"
                >
                  <HiOutlineDocumentDownload className="text-lg" />
                  Resume
                </a>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.nav>
  );
};

export default Navbar;